# Discord Music Bot (สำหรับ GitHub + Deploy ได้ทันที)

## ฟีเจอร์:
- เล่นเพลงจาก YouTube ด้วยคำสั่ง !play
- รองรับคำสั่งพื้นฐาน เช่น:
  - !join / !leave
  - !play <ลิงก์หรือชื่อเพลง>
  - !pause / !resume / !skip

## วิธีใช้บนเครื่อง (Termux หรือ PC)
1. ติดตั้ง Python และ ffmpeg
2. ติดตั้ง dependencies:
```
pip install -r requirements.txt
```
3. ตั้ง Environment Variable ชื่อ `BOT_TOKEN`
หรือแก้ตรงใน `bot.py` เพื่อใส่ token
4. รันบอท:
```
python bot.py
```

## โฮสต์บน Render (24/7)
1. อัปโหลด repo นี้ไป GitHub
2. สร้าง Web Service หรือ Background Worker ใน Render
3. เพิ่ม Environment Variable ชื่อ `BOT_TOKEN`
4. ใช้คำสั่งรัน: `python bot.py`

บอทจะออนไลน์ตลอด 24 ชั่วโมง!
