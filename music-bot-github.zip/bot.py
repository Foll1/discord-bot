import discord
from discord.ext import commands
import yt_dlp
import asyncio
import os

intents = discord.Intents.all()
bot = commands.Bot(command_prefix='!', intents=intents)

queues = {}

def check_queue(ctx, voice):
    if queues.get(ctx.guild.id):
        source = queues[ctx.guild.id].pop(0)
        voice.play(source, after=lambda x=None: check_queue(ctx, voice))

@bot.command()
async def join(ctx):
    if ctx.author.voice:
        channel = ctx.author.voice.channel
        await channel.connect()
    else:
        await ctx.send("คุณต้องอยู่ในห้องเสียงก่อน!")

@bot.command()
async def leave(ctx):
    if ctx.voice_client:
        await ctx.guild.voice_client.disconnect()
    else:
        await ctx.send("บอทไม่ได้อยู่ในห้องเสียง")

@bot.command()
async def play(ctx, *, url):
    ydl_opts = {
        'format': 'bestaudio',
        'noplaylist': 'True',
        'quiet': True,
        'default_search': 'ytsearch',
        'source_address': '0.0.0.0'
    }

    voice = discord.utils.get(bot.voice_clients, guild=ctx.guild)
    if not voice:
        if ctx.author.voice:
            channel = ctx.author.voice.channel
            voice = await channel.connect()
        else:
            await ctx.send("คุณต้องอยู่ในห้องเสียงก่อน!")
            return

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=False)
        url2 = info['url']
        title = info.get('title', 'Unknown')
        source = await discord.FFmpegOpusAudio.from_probe(url2, method='fallback')

        if voice.is_playing():
            if ctx.guild.id in queues:
                queues[ctx.guild.id].append(source)
            else:
                queues[ctx.guild.id] = [source]
            await ctx.send(f"เพิ่มเข้าคิว: {title}")
        else:
            voice.play(source, after=lambda x=None: check_queue(ctx, voice))
            await ctx.send(f"กำลังเล่น: {title}")

@bot.command()
async def pause(ctx):
    if ctx.voice_client.is_playing():
        ctx.voice_client.pause()
        await ctx.send("⏸️ หยุดเพลงแล้ว")

@bot.command()
async def resume(ctx):
    if ctx.voice_client.is_paused():
        ctx.voice_client.resume()
        await ctx.send("▶️ เล่นเพลงต่อแล้ว")

@bot.command()
async def skip(ctx):
    if ctx.voice_client.is_playing():
        ctx.voice_client.stop()
        await ctx.send("⏭️ ข้ามเพลงแล้ว")

bot.run(os.getenv("BOT_TOKEN"))
